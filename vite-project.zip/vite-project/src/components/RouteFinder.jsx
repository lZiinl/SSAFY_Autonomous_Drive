import React, { useState, useEffect } from "react";
import { FaRoad, FaClock, FaMapMarkerAlt } from "react-icons/fa";

const ROS_WEBSOCKET_URL = "ws://192.168.56.101:9090";

const RouteFinder = () => {
  const [localEndPoint, setLocalEndPoint] = useState(""); // 도착지 상태
  const [selectedOption, setSelectedOption] = useState("distance"); // 기본값은 '최단 거리'
  const [result, setResult] = useState(null);
  const [ws, setWs] = useState(null); // WebSocket 상태 관리
  const [showDropdown, setShowDropdown] = useState(false); // 드롭다운 표시 상태
  const [filteredDestinations, setFilteredDestinations] = useState([]); // 필터링된 목적지 리스트
  const [currentPage, setCurrentPage] = useState(0); // 현재 페이지 번호
  const [waypointCount, setWaypointCount] = useState(0); // 웨이포인트 갯수

  // 목적지 목록과 매핑된 숫자
  const destinations = [
    { id: 8, name: "뜨레쥬르" },
    { id: 9, name: "엔제리너스" },
    { id: 10, name: "베스킨라빈스" },
    { id: 11, name: "싸이버거" },
    { id: 12, name: "롯데마트" },
    { id: 13, name: "만나자연탄구이" },
    { id: 14, name: "한상" },
    { id: 15, name: "버거킹" },
    { id: 16, name: "KFC" },
    { id: 17, name: "미미참치" },
    { id: 18, name: "롯데리아" },
    { id: 19, name: "흑석엔젤" },
    { id: 20, name: "싸피" },
    { id: 21, name: "카페비노" },
    { id: 22, name: "수완엔젤" },
    { id: 23, name: "우리집" },
  ];

  const ITEMS_PER_PAGE = 5; // 한 페이지에 보여줄 아이템 수

  // WebSocket 연결 설정 및 waypoint count 구독
  useEffect(() => {
    const socket = new WebSocket(ROS_WEBSOCKET_URL);

    socket.onopen = () => {
      console.log("WebSocket 연결됨");

      // Waypoint count 구독 메시지 전송
      const subscribeMessage = {
        op: "subscribe",
        topic: "/waypoint_count",
      };
      socket.send(JSON.stringify(subscribeMessage));
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.topic === "/waypoint_count") {
        const count = data.msg.data; // 웨이포인트 갯수
        setWaypointCount(count);
        console.log(`받은 웨이포인트 갯수: ${count}`);
      }
    };

    socket.onclose = () => {
      console.log("WebSocket 연결 끊김");
    };

    socket.onerror = (error) => {
      console.error("WebSocket 오류:", error);
    };

    setWs(socket); // WebSocket 객체 저장

    return () => {
      if (socket) {
        socket.close(); // 컴포넌트 언마운트 시 소켓 종료
      }
    };
  }, []);

  // 경로 탐색 버튼 클릭 시 경로 계산 결과 출력 및 ROS 토픽 발행
  const handleFindRoute = () => {
    if (localEndPoint) {
      // 선택한 목적지에 해당하는 객체 찾기
      const destinationObj = destinations.find(
        (dest) => dest.name === localEndPoint
      );

      if (!destinationObj) {
        alert("유효한 도착지를 선택해주세요.");
        return;
      }

      // 평균 속도 30km/h로 계산
      const distance = waypointCount * 10; // 웨이포인트 1개당 10m 가정
      const speed = 30 * 1000 / 60; // 30km/h를 분당 미터로 변환
      const time = distance / speed; // 분 단위로 소요 시간 계산

      // 선택한 옵션에 따라 ROS 토픽 메시지 발행
      let optionValue;

      if (selectedOption === "distance") {
        optionValue = 1;
      } else if (selectedOption === "cost") {
        optionValue = 2;
      } else if (selectedOption === "safeZone") {
        optionValue = 3;
      }

      // 목적지 ID 가져오기
      const destination = destinationObj.id;

      // ROS 메시지 형식
      const message = {
        op: "publish",
        topic: "/goal_data",
        msg: {
          data: [optionValue, destination],
        },
      };

      // WebSocket을 통해 메시지 전송
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
        console.log("전송된 메시지:", message); // 메시지 확인을 위한 콘솔 출력
      } else {
        console.error("WebSocket이 열려 있지 않음");
      }

      // 경로 결과 설정
      setResult({
        distance: `${(distance / 1000).toFixed(2)} km`, // 거리
        time: formatTime(time), // 소요 시간 포맷
        cost: "1,250원", // 임의 설정
        arrival: calculateArrivalTime(time), // 도착 예정 시간 계산
      });
    }
  };

  // 소요 시간을 형식에 맞게 변환하는 함수
  const formatTime = (minutes) => {
    if (minutes >= 60) {
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = Math.round(minutes % 60);
      return `${hours}시간 ${remainingMinutes}분`;
    }
    return `${Math.round(minutes)}분`;
  };

  // 도착 예정 시간 계산 함수
  const calculateArrivalTime = (minutesToAdd) => {
    const now = new Date();
    now.setMinutes(now.getMinutes() + minutesToAdd);
    return `${now.getHours()}시 ${now.getMinutes()}분 도착`;
  };

  // 경로 옵션 선택
  const handleOptionClick = (option) => {
    setSelectedOption(option); // 선택된 옵션 업데이트
  };

  // 입력 필드 클릭 시 드롭다운 표시
  const handleInputClick = () => {
    setShowDropdown(true);
    setFilteredDestinations(destinations.slice(0, ITEMS_PER_PAGE));
    setCurrentPage(0);
  };

  // 입력 필드 변경 시 필터링
  const handleInputChange = (e) => {
    const value = e.target.value;
    setLocalEndPoint(value);

    if (value === "") {
      setFilteredDestinations(destinations.slice(0, ITEMS_PER_PAGE));
      setCurrentPage(0);
    } else {
      const filtered = destinations.filter((dest) =>
        dest.name.includes(value)
      );
      setFilteredDestinations(
        filtered.slice(0, ITEMS_PER_PAGE * (currentPage + 1))
      );
    }
  };

  // 목적지 선택 시
  const handleDestinationSelect = (name) => {
    setLocalEndPoint(name);
    setShowDropdown(false);
  };

  // 더보기 버튼 클릭 시
  const handleLoadMore = () => {
    const nextPage = currentPage + 1;
    setCurrentPage(nextPage);
    setFilteredDestinations(
      destinations.slice(0, ITEMS_PER_PAGE * (nextPage + 1))
    );
  };

  // 외부 클릭 시 드롭다운 닫기
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        event.target.closest(".dropdown") === null &&
        event.target.closest(".input-field") === null
      ) {
        setShowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="w-full h-full p-8 bg-white flex flex-col justify-start relative">
      <h2 className="text-4xl font-bold mb-6 text-center text-blue-500">경로 찾기</h2>

      {/* 도착지 입력 필드 및 경로 탐색 버튼 */}
      <div className="flex items-center mb-6 space-x-4">
        <div className="relative flex-grow">
          <input
            type="text"
            className="input-field w-full border border-gray-300 rounded-lg p-4 text-lg"
            placeholder="도착지 입력"
            value={localEndPoint}
            onChange={handleInputChange}
            onClick={handleInputClick}
          />
          {/* 드롭다운 리스트 */}
          {showDropdown && (
            <div className="dropdown absolute top-full left-0 right-0 bg-white border border-gray-300 rounded-b-lg max-h-60 overflow-y-auto z-10">
              {filteredDestinations.map((dest, index) => (
                <div
                  key={index}
                  className="p-4 hover:bg-blue-200 cursor-pointer text-blue-500"
                  onClick={() => handleDestinationSelect(dest.name)}
                >
                  {dest.name}
                </div>
              ))}
              {filteredDestinations.length < destinations.length && (
                <button
                  className="w-full p-4 text-blue-500 hover:bg-blue-200"
                  onClick={handleLoadMore}
                >
                  더보기
                </button>
              )}
            </div>
          )}
        </div>
        <button
          className="w-1/4 bg-blue-500 text-white px-6 py-4 rounded-lg text-lg"
          onClick={handleFindRoute}
        >
          경로 탐색
        </button>
      </div>

      {/* 경로 옵션 선택 (버튼 형식) */}
      <div className="mb-6">
        <h3 className="text-xl font-semibold mb-4 text-blue-500">경로 옵션 선택</h3>
        <div className="flex space-x-4">
          <button
            className={`flex-grow p-4 rounded-lg font-semibold text-white ${
              selectedOption === "distance" ? "bg-blue-500" : "bg-gray-400"
            }`}
            onClick={() => handleOptionClick("distance")}
          >
            최단 거리
          </button>

          <button
            className={`flex-grow p-4 rounded-lg font-semibold text-white ${
              selectedOption === "cost" ? "bg-blue-500" : "bg-gray-400"
            }`}
            onClick={() => handleOptionClick("cost")}
          >
            최소 비용
          </button>

          <button
            className={`flex-grow p-4 rounded-lg font-semibold text-white ${
              selectedOption === "safeZone" ? "bg-blue-500" : "bg-gray-400"
            }`}
            onClick={() => handleOptionClick("safeZone")}
          >
            보호구역 회피
          </button>
        </div>
      </div>

      {/* 경로 결과 출력 */}
      {result && (
        <div className="mt-6 p-6 bg-blue-100 rounded-lg">
          <h4 className="text-2xl font-bold mb-4 text-blue-500">탐색 결과</h4>
          <div className="flex items-center mb-2">
            <FaRoad className="text-blue-500 text-2xl mr-2" />
            <p className="text-xl text-blue-500">거리: {result.distance}</p>
          </div>
          <div className="flex items-center mb-2">
            <FaClock className="text-blue-500 text-2xl mr-2" />
            <p className="text-xl text-blue-500">소요 시간: {result.time}</p>
          </div>
          <div className="flex items-center mb-2">
            <FaMapMarkerAlt className="text-blue-500 text-2xl mr-2" />
            <p className="text-xl text-blue-500">도착 예정: {result.arrival}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default RouteFinder;
