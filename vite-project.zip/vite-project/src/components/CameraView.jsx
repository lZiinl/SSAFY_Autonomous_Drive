const CameraView = () => {
    return (
      <div>
        <h2>카메라 화면</h2>
        <button>어라운드 뷰</button>
        <button>후방 카메라</button>
      </div>
    );
  };
  
  export default CameraView;
  