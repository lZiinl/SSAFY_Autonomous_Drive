#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from morai_msgs.msg import EgoVehicleStatus
import math
from std_msgs.msg import Float32  # 데이터를 전송할 때 사용할 메시지 타입

# m/s 속도를 km/h로 변환하는 함수
def convert_mps_to_kmph(velocity_mps):
    return velocity_mps * 3.6

# 로컬 좌표계에서 세계 좌표계로 속도 변환
def convert_velocity_to_world(data):
    heading_rad = math.radians(data.heading)  # 헤딩 값을 라디안으로 변환
    velocity_x_local = data.velocity.x
    velocity_y_local = data.velocity.y

    # 로컬 좌표계 속도를 세계 좌표계 속도로 변환
    velocity_x_world = velocity_x_local * math.cos(heading_rad) - velocity_y_local * math.sin(heading_rad)
    velocity_y_world = velocity_x_local * math.sin(heading_rad) + velocity_y_local * math.cos(heading_rad)

    return velocity_x_world, velocity_y_world

# Callback 함수 생성 및 데이터 출력
def EgoStatus_callback(data):
    rospy.loginfo('------------------Ego Vehicle Status------------------')

    # 위치 정보 출력
    rospy.loginfo('position     : x = {0} , y = {1}, z = {2}'.format(data.position.x, data.position.y, data.position.z))
    
    # 속도 정보 출력 (각 축별 속도 - 로컬 좌표계)
    rospy.loginfo('velocity (local)     : x = {0} , y = {1}, z = {2} m/s'.format(data.velocity.x, data.velocity.y, data.velocity.z))
    
    # 로컬 좌표계에서 세계 좌표계로 속도 변환
    velocity_x_world, velocity_y_world = convert_velocity_to_world(data)

    # 변환된 속도 크기 계산 (m/s 단위)
    velocity_magnitude_mps = math.sqrt(velocity_x_world**2 + velocity_y_world**2 + data.velocity.z**2)
    
    # 속도 값을 km/h로 변환
    velocity_magnitude_kmph = convert_mps_to_kmph(velocity_magnitude_mps)

    # 속도 값을 새로운 토픽으로 게시
    velocity_pub = rospy.Publisher('/vehicle_speed_kmph', Float32, queue_size=10)
    velocity_pub.publish(velocity_magnitude_kmph)

    # 변환된 속도 출력
    rospy.loginfo('speed (magnitude of velocity) : {0} km/h'.format(velocity_magnitude_kmph))

def listener():
    # ROS 노드 이름 선언
    rospy.init_node('Ego_status_listener', anonymous=True)

    # Subscriber 생성
    rospy.Subscriber('/Ego_topic', EgoVehicleStatus, EgoStatus_callback)

    # Topic Subscriber 생성
    rospy.spin()

if __name__ == '__main__':
    listener()