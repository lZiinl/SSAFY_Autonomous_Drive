#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
import rospkg
import sys
import os
import numpy as np
from math import sqrt, pow
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Path
from std_msgs.msg import Float32MultiArray, Int32
from pyproj import Proj, transform
import tf

current_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(current_path)

from lib.mgeo.class_defs import *  # MGeo 관련 클래스 로드

class AStarPlanner:
    def __init__(self, nodes, links):
        self.nodes = nodes
        self.links = links
        self.heuristic_type = None

        self.custom_heuristic_2 = {
            'A119BS010184': 10000,
            'A119BS010244': 10000,
            'A119BS010172': 10000,
            'A119BS010160': 10000,
            'A119BS010232': 10000,
            'A119BS010163': 10000,
            'A119BS010237': 10000,
            'A119BS010705': 10000,
            'A119BS010281': 10000,
            'A119BS010189': 10000,
            'A119BS010210': 10000,
            'A119BS010278': 10000,
            'A119BS010149': 10000,
            'A119BS010212': 10000,
            'A119BS010209': 10000,
            'A119BS010717': 10000,
            'A119BS010157': 10000,
            'A119BS010701': 10000,
            'A119BS010282': 10000,
            'A119BS010281': 10000,
            'A119BS010707': 10000,
            'A119BS010222': 10000,
            'A119BS010712': 10000,
        }

        self.custom_heuristic_3 = {
            'A119BS010168': 10000,
            'A119BS010240': 10000,
            'A119BS010163': 10000,
            'A119BS010237': 10000,
            'A119BS010234': 10000,
            'A119BS010162': 10000,
            'A119BS010715': 10000,
            'A119BS010714': 10000,
            'A119BS010713': 10000,
            'A119BS010712': 10000,
            'A119BS010280': 10000,
            'A119BS010157': 10000,
            'A119BS010701': 10000,
            'A119BS010282': 10000,
            'A119BS010281': 10000,
            'A119BS010707': 10000,
            'A119BS010222': 10000,
            'A119BS010712': 10000,
        }

    def set_heuristic_type(self, heuristic_type):
        self.heuristic_type = heuristic_type

    def calculate_heuristic(self, node, goal_node):
        if self.heuristic_type == 1:
            node_point = self.nodes[node].point
            goal_point = self.nodes[goal_node].point
            node_x = node_point[0]
            node_y = node_point[1]
            goal_x = goal_point[0]
            goal_y = goal_point[1]
            return sqrt(pow(goal_x - node_x, 2) + pow(goal_y - node_y, 2))
        elif self.heuristic_type == 2:
            if node in self.custom_heuristic_2:
                return self.custom_heuristic_2[node]
            else:
                return 0
        elif self.heuristic_type == 3:
            if node in self.custom_heuristic_3:
                return self.custom_heuristic_3[node]
            else:
                return 0

    def find_shortest_path(self, start_node_idx, end_node_idx):
        open_list = set([start_node_idx])
        closed_list = set()
        g_costs = {start_node_idx: 0}
        f_costs = {start_node_idx: self.calculate_heuristic(start_node_idx, end_node_idx)}
        from_node = {}

        while open_list:
            current_node = min(open_list, key=lambda node: f_costs[node])
            if current_node == end_node_idx:
                path = []
                while current_node in from_node:
                    path.append(current_node)
                    current_node = from_node[current_node]
                path.append(start_node_idx)
                path.reverse()
                return path

            open_list.remove(current_node)
            closed_list.add(current_node)

            current_node_obj = self.nodes[current_node]
            for neighbor in current_node_obj.get_to_nodes():
                if neighbor.idx in closed_list:
                    continue

                tentative_g_cost = g_costs[current_node] + self.get_cost(current_node, neighbor.idx)

                if neighbor.idx not in open_list:
                    open_list.add(neighbor.idx)
                elif tentative_g_cost >= g_costs[neighbor.idx]:
                    continue

                from_node[neighbor.idx] = current_node
                g_costs[neighbor.idx] = tentative_g_cost
                f_costs[neighbor.idx] = g_costs[neighbor.idx] + self.calculate_heuristic(neighbor.idx, end_node_idx)

        return None

    def get_cost(self, from_node_idx, to_node_idx):
        from_node = self.nodes[from_node_idx]
        to_node = self.nodes[to_node_idx]
        shortest_link, min_cost = self.find_shortest_link_leading_to_node(from_node, to_node)
        return min_cost

    def find_shortest_link_leading_to_node(self, from_node, to_node):
        to_links = [link for link in from_node.get_to_links() if link.to_node == to_node]
        shortest_link = min(to_links, key=lambda link: link.cost) if to_links else None
        min_cost = shortest_link.cost if shortest_link else float('inf')
        return shortest_link, min_cost


class AStarPathPublisher:
    def __init__(self):
        rospy.init_node('a_star_path_pub', anonymous=True)

        # 경로 퍼블리셔 설정
        self.global_path_pub = rospy.Publisher('/global_path', Path, queue_size=1)
        # 웨이포인트 갯수를 퍼블리시할 새로운 토픽 설정
        self.waypoint_count_pub = rospy.Publisher('/waypoint_count', Int32, queue_size=1)

        rospy.Subscriber('/utm_coordinates', Float32MultiArray, self.utm_callback)
        rospy.Subscriber('/goal_data', Float32MultiArray, self.goal_data_callback)

        # MGeo 데이터 로드
        load_path = os.path.normpath(os.path.join(current_path, 'lib/mgeo_data/R_KR_PG_K-City'))
        mgeo_planner_map = MGeo.create_instance_from_json(load_path)

        self.nodes = mgeo_planner_map.node_set.nodes
        self.links = mgeo_planner_map.link_set.lines

        self.global_planner = AStarPlanner(self.nodes, self.links)

        self.is_goal_pose = False
        self.is_init_pose = False
        self.init_x = None
        self.init_y = None

        self.start_node = None
        self.end_node = None
        self.nearest_node = None

        self.nearest_link = None
        self.nearest_point_index = None

        self.goal_node_dict = {
            1: ['A119BS010256'],
            2: ['A119BS010184'],
            3: ['A119BS010244', 'A119BS010172'],
            4: ['A119BS010239', 'A119BS010165'],
            5: ['A119BS010160', 'A119BS010232'],
            6: ['A119BS010168', 'A119BS010240'],
            7: ['A119BS010163', 'A119BS010237'],
            8: ['A119BS010234', 'A119BS010162'],
            9: ['A119BS010218', 'A119BS010218', 'A119BS010269', 'A119BS010269'],
            10: ['A119BS010220', 'A119BS010151'],
            11: ['A119BS010705', 'A119BS010704', 'A119BS010281', 'A119BS010189'],
            12: ['A119BS010155', 'A119BS010228'],
            13: ['A119BS010715', 'A119BS010714', 'A119BS010713', 'A119BS010712', 'A119BS010280'],
            14: ['A119BS010275', 'A119BS010273', 'A119BS010217', 'A119BS010285'],
            15: ['A119BS010210', 'A119BS010210', 'A119BS010278', 'A119BS010278'],
            16: ['A119BS010149', 'A119BS010212'],
            17: ['A119BS010191', 'A119BS010294'],
            18: ['A119BS010229', 'A119BS010156'],
            19: ['A119BS010312', 'A119BS010313', 'A119BS010314', 'A119BS010315'],
            20: ['A119BS010202', 'A119BS010141'],
            21: ['A119BS010142', 'A119BS010201'],
            22: ['A119BS010209', 'A119BS010717'],
            23: ['A119BS010206', 'A119BS010206'],
        }

        self.selected_goal_node_id = None

        self.proj_UTM = Proj(proj='utm', zone=52, ellps='WGS84', preserve_units=False)
        self.proj_WGS84 = Proj(proj='latlong', datum='WGS84')

        self.listener = tf.TransformListener()

    def find_nearest_link_and_point(self, x, y):
        min_distance = float('inf')
        nearest_link = None
        nearest_point_index = None

        for link_idx in self.links:
            link = self.links[link_idx]
            for i, point in enumerate(link.points):
                point_x = point[0]
                point_y = point[1]
                distance = sqrt(pow(x - point_x, 2) + pow(y - point_y, 2))
                if distance < min_distance:
                    min_distance = distance
                    nearest_link = link
                    nearest_point_index = i

        return nearest_link, nearest_point_index


    def utm_callback(self, msg):
        # 현재 위치를 tf를 통해 얻습니다.
        try:
            (trans, _) = self.listener.lookupTransform('map', 'base_link', rospy.Time(0))
            self.init_x = trans[0]
            self.init_y = trans[1]

            start_min_dis = float('inf')
            for node_idx in self.nodes:
                node_pose_x = self.nodes[node_idx].point[0]
                node_pose_y = self.nodes[node_idx].point[1]
                start_dis = sqrt(pow(self.init_x - node_pose_x, 2) + pow(self.init_y - node_pose_y, 2))
                if start_dis < start_min_dis:
                    start_min_dis = start_dis
                    self.nearest_node = node_idx

            # 가장 가까운 링크와 해당 링크에서의 인덱스를 찾습니다.
            self.nearest_link, self.nearest_point_index = self.find_nearest_link_and_point(self.init_x, self.init_y)

        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            self.nearest_node = None
            self.nearest_link = None
            self.nearest_point_index = None

        self.start_node = self.nearest_node
        self.is_init_pose = True

    def goal_data_callback(self, msg):
        heuristic_type = int(msg.data[0])
        input_goal_index = int(msg.data[1])

        rospy.loginfo("받은 휴리스틱 타입: {0}, 목표 노드 인덱스: {1}".format(heuristic_type, input_goal_index))

        self.global_planner.set_heuristic_type(heuristic_type)

        if input_goal_index in self.goal_node_dict:
            nodes_in_index = self.goal_node_dict[input_goal_index]
            rospy.loginfo("인덱스 {0}의 목표 노드들: {1}".format(input_goal_index, nodes_in_index))

            closest_node = None
            closest_dist = float('inf')

            for node_id in nodes_in_index:
                for node_idx in self.nodes:
                    if self.nodes[node_idx].idx == node_id:
                        node_x = self.nodes[node_idx].point[0]
                        node_y = self.nodes[node_idx].point[1]
                        dist = sqrt(pow(self.init_x - node_x, 2) + pow(self.init_y - node_y, 2))
                        if dist < closest_dist:
                            closest_dist = dist
                            closest_node = node_idx

            if closest_node is not None:
                self.end_node = closest_node
                rospy.loginfo("가장 가까운 노드 ID: {0}".format(self.nodes[self.end_node].idx))
                self.is_goal_pose = True
                self.calculate_and_publish_path()  # 경로를 한번만 계산하고 퍼블리시
            else:
                rospy.logwarn('목표 노드 선택 실패')

        else:
            rospy.logwarn('잘못된 목표 노드 인덱스입니다.')

    def calculate_and_publish_path(self):
        if self.is_goal_pose and self.is_init_pose and self.start_node is not None and self.end_node is not None:
            rospy.loginfo('경로 계산 중...')
            global_path_msg = self.calc_a_star_path(self.start_node, self.end_node)
            self.global_path_pub.publish(global_path_msg)  # 경로를 퍼블리시
            rospy.loginfo('경로 퍼블리시 완료.')
        else:
            rospy.loginfo('UTM 좌표 또는 목표 지점 정보가 불충분합니다.')

    def calc_a_star_path(self, start_node, end_node):
        path_nodes = self.global_planner.find_shortest_path(start_node, end_node)

        out_path = Path()
        out_path.header.frame_id = '/map'

        # 경로의 웨이포인트 개수 초기화
        waypoint_count = 0

        # 현재 위치를 경로에 추가합니다.
        link_pose = PoseStamped()
        link_pose.pose.position.x = self.init_x
        link_pose.pose.position.y = self.init_y
        link_pose.pose.orientation.w = 1
        out_path.poses.append(link_pose)
        waypoint_count += 1  # 웨이포인트 추가

        # 현재 위치에서 가장 가까운 노드까지의 경로를 추가합니다.
        if self.nearest_link is not None and self.nearest_point_index is not None:
            if self.nearest_link.from_node.idx == self.nearest_node:
                indices = range(self.nearest_point_index, -1, -1)
            else:
                indices = range(self.nearest_point_index, len(self.nearest_link.points))

            for i in indices:
                point = self.nearest_link.points[i]
                link_pose = PoseStamped()
                link_pose.pose.position.x = point[0]
                link_pose.pose.position.y = point[1]
                link_pose.pose.orientation.w = 1
                out_path.poses.append(link_pose)
                waypoint_count += 1  # 웨이포인트 추가

        # A* 알고리즘을 통해 찾은 경로를 추가합니다.
        if path_nodes:
            for i in range(len(path_nodes) - 1):
                current_node = path_nodes[i]
                next_node = path_nodes[i + 1]

                # 현재 노드와 다음 노드 사이의 링크를 찾습니다.
                current_node_obj = self.nodes[current_node]
                next_node_obj = self.nodes[next_node]
                shortest_link, _ = self.global_planner.find_shortest_link_leading_to_node(current_node_obj, next_node_obj)

                if shortest_link is not None:
                    # 링크에 있는 점들을 경로에 추가합니다.
                    for point in shortest_link.points:
                        link_pose = PoseStamped()
                        link_pose.pose.position.x = point[0]
                        link_pose.pose.position.y = point[1]
                        link_pose.pose.orientation.w = 1
                        out_path.poses.append(link_pose)
                        waypoint_count += 1  # 웨이포인트 추가

        # 웨이포인트 개수를 퍼블리시
        self.waypoint_count_pub.publish(waypoint_count)

        return out_path


if __name__ == '__main__':
    try:
        a_star_publisher = AStarPathPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
