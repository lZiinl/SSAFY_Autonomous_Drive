#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import CompressedImage
import cv2
import numpy as np
import base64
from flask import Flask
from flask_socketio import SocketIO
import threading
import ctypes
from flask_cors import CORS
import signal
import sys
import time

# X11 스레드 초기화
libX11 = ctypes.cdll.LoadLibrary('libX11.so')
libX11.XInitThreads()

# Flask 및 SocketIO 설정
app = Flask(__name__, static_url_path=None)
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading',transports=['polling'])

# 카메라 이미지를 저장할 전역 변수
images = [None, None, None, None]
previous_images = [None, None, None, None]  # 이전 이미지 저장

# 화면 크기 및 설정
frame_width = 720
frame_height = 980

# 차량 이미지 로드
vehicle_image_path = '/home/ssafy/catkin_ws/src/ssafy_1/scripts/images/genesis.png'
vehicle_image = cv2.imread(vehicle_image_path, cv2.IMREAD_UNCHANGED)

if vehicle_image is None:
    raise IOError("Vehicle image not found at path: {}".format(vehicle_image_path))

vehicle_image = cv2.resize(vehicle_image, (280, 595))
bgr_vehicle = vehicle_image[:, :, :3]
alpha_vehicle = vehicle_image[:, :, 3]
mask_vehicle = cv2.threshold(alpha_vehicle, 1, 255, cv2.THRESH_BINARY)[1]

# 중앙 사각형 좌표 등
center_points = [(255, 265), (465, 265), (465, 735), (255, 735)]
corners = [(0, 0), (frame_width, 0), (frame_width, frame_height), (0, frame_height)]
dest_points = [
    [corners[0], corners[1], center_points[1], center_points[0]],
    [corners[2], corners[3], center_points[3], center_points[2]],
    [corners[3], corners[0], center_points[0], center_points[3]],
    [corners[1], corners[2], center_points[2], center_points[1]]
]

# 카메라 원본 좌표
src_points = np.float32([[0, 0], [640, 0], [640, 480], [0, 480]])
 
# ROS 카메라 콜백 함수
def Camera_callback(data, camera_index):
    global images
    np_arr = np.frombuffer(data.data, np.uint8)
    img_bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    height, width = img_bgr.shape[:2]

        # 카메라 인덱스에 따라 투시 변환 좌표 설정
    if camera_index == 0:
        p1 = [154, 267]  # 좌상
        p2 = [490, 267]  # 우상
        p3 = [600, 480]  # 우하
        p4 = [20, 480]   # 좌하
    elif camera_index == 1:
        p1 = [154, 287]  # 좌상
        p2 = [490, 287]  # 우상
        p3 = [600, 460]  # 우하
        p4 = [20, 460]   # 좌하
    elif camera_index == 2:  # 좌
        p1 = [188, 227]
        p2 = [443, 227]
        p3 = [620, 436]
        p4 = [20, 456]
    elif camera_index == 3:  # 우
        p1 = [188, 227]
        p2 = [443, 227]
        p3 = [620, 456]
        p4 = [20, 456]

    # 투시 변환 적용
    corner_points_arr = np.float32([p1, p2, p3, p4])
    image_params = np.float32([[0, 0], [width, 0], [width, height], [0, height]])
    mat = cv2.getPerspectiveTransform(corner_points_arr, image_params)
    img_bgr = cv2.warpPerspective(img_bgr, mat, (width, height))

    # 목적지 좌표로 변환
    dst_points_camera = np.float32(dest_points[camera_index])
    matrix = cv2.getPerspectiveTransform(src_points, dst_points_camera)
    transformed_image = cv2.warpPerspective(img_bgr, matrix, (frame_width, frame_height))

    images[camera_index] = transformed_image

# 이미지 스티칭 및 전송 함수
def stitch_images():
    global images, previous_images, bgr_vehicle, mask_vehicle

    if all(np.array_equal(img, prev_img) for img, prev_img in zip(images, previous_images)):
        return
    previous_images = [np.copy(img) for img in images]  # 이미지 업데이트

    stitched_image = np.zeros((frame_height, frame_width, 3), dtype=np.uint8)
    try:
        for img in images:
            if img is not None:
                stitched_image = cv2.add(stitched_image, img)
    except cv2.error as e:
        print("Error stitching images: ", e)
        return

    center_x = frame_width // 2 - bgr_vehicle.shape[1] // 2
    center_y = frame_height // 2 - bgr_vehicle.shape[0] // 2
    roi = stitched_image[center_y:center_y + bgr_vehicle.shape[0], center_x:center_x + bgr_vehicle.shape[1]]
    roi[np.where(mask_vehicle)] = bgr_vehicle[np.where(mask_vehicle)]

    _, buffer = cv2.imencode('.jpg', stitched_image, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
    jpg_as_text = base64.b64encode(buffer).decode('utf-8')
    socketio.emit('image', jpg_as_text)

        # 기존 이미지를 처리 후 메모리 해제 (중요)
    for i in range(len(images)):
        images[i] = None

# 주기적으로 이미지를 전송하는 Background Task 함수
def send_images_periodically():
    frame_interval = 1.0 / 15.0  # 1초에 15프레임
    while True:
        if all(image is not None for image in images):
            stitch_images()
        time.sleep(frame_interval)

# Flask-SocketIO 서버 실행 함수
def run_flask():
    print("Flask server starting")
    socketio.start_background_task(send_images_periodically)
    socketio.run(app, host='0.0.0.0', port=5123, debug=True, use_reloader=False, log_output=True)

# ROS 노드 시작 함수
def listener():
    print("ROS node started")
    rospy.init_node('multi_camera_listener', anonymous=True)
    rospy.Subscriber('/camera1/image_jpeg/compressed', CompressedImage, Camera_callback, callback_args=0)
    rospy.Subscriber('/camera2/image_jpeg/compressed', CompressedImage, Camera_callback, callback_args=1)
    rospy.Subscriber('/camera3/image_jpeg/compressed', CompressedImage, Camera_callback, callback_args=2)
    rospy.Subscriber('/camera4/image_jpeg/compressed', CompressedImage, Camera_callback, callback_args=3)
    rospy.spin()

# 메인 실행
if __name__ == '__main__':
    signal.signal(signal.SIGINT, lambda sig, frame: sys.exit(0))

    # Flask 서버를 별도의 스레드에서 실행
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.start()

    # ROS 노드를 메인 스레드에서 실행
    listener()