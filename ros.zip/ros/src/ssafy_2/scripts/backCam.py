#!/usr/bin/env python
# -*- coding: utf-8 -*-

import rospy
from sensor_msgs.msg import CompressedImage
from morai_msgs.msg import EgoVehicleStatus  # 차량 상태를 받기 위한 메시지
import cv2
import numpy as np
import base64
from flask import Flask
from flask_socketio import SocketIO
import threading
import ctypes
from flask_cors import CORS
import signal
import sys
import time

# X11 스레드 초기화
libX11 = ctypes.cdll.LoadLibrary('libX11.so')
libX11.XInitThreads()

# Flask 및 SocketIO 설정
app = Flask(__name__, static_url_path=None)
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', transports=['polling'])

# 카메라 이미지를 저장할 전역 변수
images = None
current_wheel_angle = 0.0  # 바퀴 각도 초기화
current_speed = 0.0  # 속도 초기화

# 창 크기 설정
WINDOW_WIDTH = 720
WINDOW_HEIGHT = 980
VEHICLE_WIDTH = 150  # 차량의 폭 (픽셀 단위)
BASE_WHEEL_SCALING_FACTOR = 0.3
MAX_CURVATURE = 200
HORIZONTAL_SHIFT = 50

# 카메라 콜백 함수
def Camera_callback(data):
    global current_wheel_angle, current_speed
    
    # ROS 메시지를 numpy 배열로 변환
    np_arr = np.frombuffer(data.data, np.uint8)
    
    # 이미지 디코딩
    img_bgr = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    
    # 이미지 크기를 width 720, height 980로 리사이즈
    img_resized = cv2.resize(img_bgr, (WINDOW_WIDTH, WINDOW_HEIGHT))
    
    # 주차선 이미지 로드
    parking_line_path = '/home/ssafy/catkin_ws/src/ssafy_1/scripts/images/parkingLine.png'
    parking_line_img = cv2.imread(parking_line_path, cv2.IMREAD_UNCHANGED)
    
    # 주차선 이미지도 크기를 카메라 이미지에 맞게 조정
    parking_line_resized = cv2.resize(parking_line_img, (WINDOW_WIDTH, WINDOW_HEIGHT))
    
    # 투명한 이미지 합성 처리
    if parking_line_resized.shape[2] == 4:  # RGBA 포맷인 경우
        alpha_mask = parking_line_resized[:, :, 3] / 255.0  # 알파 채널 추출
        for c in range(0, 3):
            img_resized[:, :, c] = (1.0 - alpha_mask) * img_resized[:, :, c] + alpha_mask * parking_line_resized[:, :, c]
    else:
        img_resized = cv2.addWeighted(img_resized, 0.7, parking_line_resized, 0.3, 0)

    # 바퀴 경로를 표시하는 함수 호출
    img_with_lines = draw_steering_paths(img_resized, current_wheel_angle, calculate_wheel_scaling_factor(current_speed))

    # 이미지를 Base64로 인코딩하여 전송
    _, buffer = cv2.imencode('.jpg', img_with_lines)
    jpg_as_text = base64.b64encode(buffer).decode('utf-8')

    # SocketIO를 통해 이미지 전송
    socketio.emit('image', jpg_as_text)

# 바퀴 경로 그리기 함수
def draw_steering_paths(img, wheel_angle, scaling_factor):
    start_left = (WINDOW_WIDTH // 2 - VEHICLE_WIDTH // 2 - HORIZONTAL_SHIFT, WINDOW_HEIGHT)
    start_right = (WINDOW_WIDTH // 2 + VEHICLE_WIDTH // 2 + HORIZONTAL_SHIFT, WINDOW_HEIGHT)
    
    curvature = int(wheel_angle * scaling_factor)
    curvature = max(-MAX_CURVATURE, min(MAX_CURVATURE, curvature))
    
    points_left = []
    points_right = []
    
    for i in range(5):
        y = WINDOW_HEIGHT - (i * 500 // 5)
        x_left = start_left[0] + curvature * (i ** 2)
        x_right = start_right[0] + curvature * (i ** 2)
        
        points_left.append((x_left, y))
        points_right.append((x_right, y))
    
    points_left = np.array(points_left, np.int32).reshape((-1, 1, 2))
    points_right = np.array(points_right, np.int32).reshape((-1, 1, 2))
    
    cv2.polylines(img, [points_left], isClosed=False, color=(0, 255, 255), thickness=20)
    cv2.polylines(img, [points_right], isClosed=False, color=(0, 255, 255), thickness=20)
    
    return img

# 속도에 따른 곡률 상수 계산 함수
def calculate_wheel_scaling_factor(speed):
    speed_factor = max(1.0, speed / 10.0)
    return BASE_WHEEL_SCALING_FACTOR * speed_factor

# 차량 상태 콜백 함수 (바퀴 각도 및 속도 업데이트)
def VehicleStatus_callback(data):
    global current_wheel_angle, current_speed
    current_wheel_angle = data.wheel_angle
    current_speed = data.velocity.x

# ROS listener function
def listener():
    rospy.init_node('camera_img_with_wheel_angle', anonymous=True)
    rospy.Subscriber('/camera5/image_jpeg/compressed', CompressedImage, Camera_callback)
    rospy.Subscriber('/Ego_topic', EgoVehicleStatus, VehicleStatus_callback)
    rospy.spin()

# Flask-SocketIO 서버 실행 함수
def run_flask():
    print("Flask server starting")
    socketio.run(app, host='0.0.0.0', port=5124, debug=True, use_reloader=False)

# SIGINT 신호 핸들러 함수
def signal_handler(sig, frame):
    print('Exiting...')
    sys.exit(0)

if __name__ == '__main__':
    # Flask 서버를 별도의 스레드에서 실행
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.start()

    # ROS 노드를 메인 스레드에서 실행
    listener()

    # SIGINT 신호 핸들러 등록
    signal.signal(signal.SIGINT, signal_handler)